create function new_thread() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE main.forums
    SET threads = threads + 1
    WHERE slug = NEW.forum;
    RETURN NEW;
END;
$$;

alter function new_thread() owner to postgres;

