create function insert_users_forum() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO main.users_forum(slug, nickname)
    VALUES (NEW.forum, NEW.author)
    ON CONFLICT DO NOTHING;
    RETURN NEW;
END;
$$;

alter function insert_users_forum() owner to postgres;

