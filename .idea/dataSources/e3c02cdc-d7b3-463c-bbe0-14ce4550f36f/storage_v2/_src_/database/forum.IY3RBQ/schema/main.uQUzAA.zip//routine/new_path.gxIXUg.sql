create function new_path() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.path = (SELECT path FROM main.posts WHERE id = NEW.parent) || NEW.id;
    RETURN NEW;
END;
$$;

alter function new_path() owner to postgres;

