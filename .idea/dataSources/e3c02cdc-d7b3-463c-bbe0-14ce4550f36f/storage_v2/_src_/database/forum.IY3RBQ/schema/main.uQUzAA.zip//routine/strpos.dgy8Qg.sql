create function strpos(main.citext, main.citext) returns integer
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT pg_catalog.strpos( pg_catalog.lower( $1::pg_catalog.text ), pg_catalog.lower( $2::pg_catalog.text ) );
$$;

alter function strpos(main.citext, main.citext) owner to postgres;

